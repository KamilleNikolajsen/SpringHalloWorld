package com.example.halloworldspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HalloWorldSpringApplicationTests {

  @Test
  void contextLoads() {
  }

}
